import React from "react";

function NotesWelcome() {
  return (
    <div className="col-md-6 d-flex align-items-center">
      <div className="col text-center">
        <h1 class="display-5">Cegah lupa ?</h1>
        <p class="lead">Catat, Simpan, Buka kapan saja dimana saja!</p>
      </div>
    </div>
  );
}

export default NotesWelcome;
