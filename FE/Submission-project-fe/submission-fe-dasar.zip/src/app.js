import 'regenerator-runtime';
import '../src/styles/output.css';
import './script/component/app-bar.js';
import main from './script/view/main.js';

document.addEventListener('DOMContentLoaded', main);
