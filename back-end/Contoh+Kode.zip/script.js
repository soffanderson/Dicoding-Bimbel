function myFunction() {
    document.getElementById("tanggal").innerHTML = "Segera hadir. Nantikan ya!";
  }